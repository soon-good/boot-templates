package io.study.jpa_sample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaSampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaSampleApplication.class, args);
	}

}
